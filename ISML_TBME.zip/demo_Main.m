function demo_Main

%%  2015-02-10 Use Ten Atlas Perform Multi-Atlas Feature Selection
% Step 1) Fist Concatenate features from 10 atlases
% Step 2) Perform sub-class clustering
% Step 3) Perform Multi-task feature selection
% Step 4) Construct a SVM classifier

clc
clear

load 'ADNC_MA_10folds_NEW.mat'
addpath(genpath('SLEP4.1'));
addpath(genpath('libsvm-3.20')); 
addpath(genpath('AP'));

fold=10;
model=[]; 
rep_num=1;

allTask_num=10;  
a_num=1;
   
for fold_num=fold %:-1:1
    
%   for a_num=1:10       
  %% Step 1: Prepare Data      
%     fea_num=1500;  
    adTr_num=length( find(folds_data{2,fold_num}==1) );
    adTe_num=length( find(folds_data{4,fold_num}==1) );
    ncTr_num=length( find(folds_data{2,fold_num}==-1) );
    ncTe_num=length( find(folds_data{4,fold_num}==-1) );
    
    X=[folds_data{1,fold_num}(:,:);
       folds_data{3,fold_num}(:,:)  ];  % use all features concatenation
    Y=[folds_data{2,fold_num};folds_data{4,fold_num}];
   
    AD=X(find(Y==1),:);
    adIndex=find(Y==1);
    NC=X(find(Y==-1),:);
    ncIndex=find(Y==-1);
    
    %% NC AP_clustering  cluster number is k.
    [s,p]=computSimilarity(NC);
    clustNum=3;
    [idx,netsim,dpsim,expref,pref]=apclusterK(s,clustNum) % clustering into k clusters
    
    ncY=zeros(size(NC,1),7 );%[];%[zeros(size(NC,1),1) 1+zeros(size(NC,1),1)];
    ncY(:,1)=0; 
    ncY(:,2)=1;  % NC code in the first layer is [0 1]
    for i=1:clustNum
        exemp=unique(idx);
        if i==1
            ncY(find(idx==exemp(i,1)),5)=1;           
        else if i==2
                ncY(find(idx==exemp(i,1)),6)=1;
            else if i==3
                   ncY(find(idx==exemp(i,1)),7)=1;
                end
            end
        end       
    end       

    %% AD AP_clustering  cluster number is k.
    [s,p]=computSimilarity(AD);
    clustNum=2;
    [idx,netsim,dpsim,expref,pref]=apclusterK(s,clustNum) % clustering into k clusters
    
    adY=zeros(size(AD,1),7 );%[];%[zeros(size(NC,1),1) 1+zeros(size(NC,1),1)];
    adY(:,1)=1; 
    adY(:,2)=0;  % NC code in the first layer is [0 1]
    for i=1:clustNum
        exemp=unique(idx);
        if i==1
            adY(find(idx==exemp(i,1)),3)=1;           
        else if i==2
                adY(find(idx==exemp(i,1)),4)=1;
            end
        end       
    end
    
    %% Prepare data and New Label
    
    trData=[]; teData=[];trLab=[];teLab=[];
    
    trData=[AD(1:adTr_num,:);NC(1:ncTr_num,:)];
    trLabel=[adY(1:adTr_num,:);ncY(1:ncTr_num,:)];
   
    teData=[AD(adTr_num+1:end,:);NC(ncTr_num+1:end,:)];
    teLabel=[adY(adTr_num+1:end,:);ncY(ncTr_num+1:end,:)];
     
    % select 10% of training data as validataion data
    ori_trLab=folds_data{2,fold_num}; % original AD=+1, NC=-1
    ori_teLab=folds_data{4,fold_num}; % original AD=+1, NC=-1
    bb=randperm(size(trData,1));
    vaData=[]; vaLabel=[];   
    vaNum=bb( 1 : fix( 0.1*size(trData,1) ) );
    vaData=trData(vaNum,:);
    vaLabel=ori_trLab(vaNum,:);

    trData(vaNum,:)=[];
    ori_trLab(vaNum,:)=[]; 
    trLabel(vaNum,:)=[];
    newTrSize=size(trData,1);
    
    %% Using L2,1 regularized Multi-task Feature Selction

    A=[];
    for ii=1:size(trLabel,2)
        A=[A;trData];
    end    
    
    ind=0:size(trData,1):size(trData,1)*size(trLabel,2);     % the 1000 samples are from 10 tasks
    [model] = model_MTFS(A, trLabel(:),ind);

    
  %% Step 3: Find the optimal parameter on validation data
  
  max=0;     
  for num=1:1:size(model.W,2) 
      
    W=model.W{1,num};    
        index=find(abs(W(:,1))>1e-4);
        tr_X=jb_scaling( trData(:,index) );
        va_X=jb_scaling( vaData(:,index) );
        te_X=jb_scaling( teData(:,index) );              
          % Linear SVM
          CC=1;
          for kkk=1:size(CC,2)
           c=CC(1,kkk);
           model_svm = svmtrain(ori_trLab, tr_X, cat(2, '-t 0 -c ' ,num2str(c) ));  % 1 linear�� 2 rbf
           [predictTr, accuracyTr, decValues_tr] = svmpredict(ori_trLab, tr_X, model_svm);  
           [predictVa, accuracyVa, decValues_Va] = svmpredict(vaLabel, va_X, model_svm);
           [predictTe, accuracyTe, decValues_Te] = svmpredict(ori_teLab, te_X, model_svm);
           [xx,yy,T,auc]=perfcurve(ori_teLab,predictTe,1);
           [accura,sen,spe,Bac,Ppv,Npv]=lmx_SenSpeAcc(predictTe,ori_teLab)
     
  
          end
   
    end % model number

  clear newTraindata newValidData newTestData tr_X te_X va_X trainLabel validLabel ;
  save result_Fold1.mat

  
end  % fold number
    
end 

