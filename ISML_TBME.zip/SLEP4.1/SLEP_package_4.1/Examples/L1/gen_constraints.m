function [M,C]=gen_constraints2(traindata,trainlabel,size_m,size_c)
%generate the must-link and cannot link constraints
%Inputs:
%   traindata  -N x D matrix,each row is a sample
%   trainlabel -N x 1 matrix,the label of the corresponding sample
%   size_m     -the number of the must-link constraints
%   size_n     -the number of the cannot-link constraints
%
%Outputs:
%     M     -The must-link constraints([i,j]:example i and example j is must-link;
%     C     _The cannot link constraints

[n,d]=size(traindata);
max_csize=n*(n-1)/2;
if max_csize<(size_m+size_c),
    disp('constraints size larger than data size!');
    size_m=0;
    size_c=0;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M1=zeros(n);C1=zeros(n);
k1=1;k2=1;
while k1<=size_m||k2<=size_c,
    rp=ceil(n*rand(1));rp2=ceil(n*rand(1));
    if trainlabel(rp)==trainlabel(rp2)&rp~=rp2&k1<=size_m&M1(rp,rp2)~=1,
        M1(rp,rp2)=1;M1(rp2,rp)=1;k1=k1+1;
    elseif trainlabel(rp)~=trainlabel(rp2)&k2<=size_c&C1(rp,rp2)~=1,
        C1(rp,rp2)=1;C1(rp2,rp)=1; k2=k2+1;
       
    end
end
count_M=1;count_C=1;
for i=1:n,
  for  j=i+1:n,
    if M1(i,j)==1,
        M(count_M,1)=i;M(count_M,2)=j;count_M=count_M+1;
    end
  end
end
for i=1:n,
    for j=i+1:n,
     if C1(i,j)==1,
        C(count_C,1)=i;C(count_C,2)=j;count_C=count_C+1;
     end
    end
end  





























    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

