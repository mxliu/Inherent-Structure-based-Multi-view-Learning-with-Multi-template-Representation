
function compMRI

% addpath /Users/ruimin/Documents/MATLAB/utilities/viewer3d/
filename1='Image_56.hdr';
filename2='Seg_56.hdr';
ImageAD1 = analyze75read(filename1);
ImageNC1 = analyze75read(filename2);

%mriplot(I);

viewer3d(ImageAD1,ImageNC1);

aa=1;




end