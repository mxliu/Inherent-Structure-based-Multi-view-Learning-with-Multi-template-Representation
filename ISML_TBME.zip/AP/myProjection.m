function [ output_args ] = myProjection( input_args )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here


end

