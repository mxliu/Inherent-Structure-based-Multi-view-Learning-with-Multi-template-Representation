function [s,p]=computSimilarity(data)
%% data is a N*d matrix, N is the sample number, d is the feature number
    for i=1:size(data,1)
        for j=1:size(data,1)
            s(i,j)=-sum((data(i,:)-data(j,:)).^2);
        end
    end
    
    aa=[];
    for i=1:size(data,1)
         for j=i+1:size(data,1)
             aa=[aa;s(i,j)];
         end
    end
    p=median(aa);

end