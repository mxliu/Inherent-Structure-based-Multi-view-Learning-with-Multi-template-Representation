%% find center point 56
clc;
clear all;


load Dissimilarity_Matrix;

distance_points=sum(Dissimilarity_Matrix,2);

[value, index]=min(distance_points);