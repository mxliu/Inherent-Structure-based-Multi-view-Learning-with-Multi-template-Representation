function [ output_args ] = singleAtlasAP(  )
%SINGLEATLASAP Summary of this function goes here
%   Detailed explanation goes here

clc
clear
load '../Rui_Data/ADNC_MA_10folds_NEW.mat'

fold=10;
model=[]; 
rep_num=1;

allTask_num=10;    
   
for fold_num=1:1:1%fold
    
  for a_num=1:10       
  %% Step 1: Prepare Data      
    fea_num=1500;  
    adTr_num=length( find(folds_data{2,fold_num}==1) );
    adTe_num=length( find(folds_data{4,fold_num}==1) );
    ncTr_num=length( find(folds_data{2,fold_num}==-1) );
    ncTe_num=length( find(folds_data{4,fold_num}==-1) );
    
    X=[folds_data{1,fold_num}(:, (a_num-1)*1500+1:(a_num-1)*1500+1500 );
       folds_data{3,fold_num}(:, (a_num-1)*1500+1:(a_num-1)*1500+1500 )];
    Y=[folds_data{2,fold_num};folds_data{4,fold_num}];
   
    AD=X(find(Y==1),:);
    adIndex=find(Y==1);
    NC=X(find(Y==-1),:);
    ncIndex=find(Y==-1);
    
    %% NC AP_clustering  cluster number is k.
    [s,p]=computSimilarity(NC);
    clustNum=3;
    [idx,netsim,dpsim,expref,pref]=apclusterK(s,clustNum) % clustering into k clusters
    
    ncY=zeros(size(NC,1),7 );%[];%[zeros(size(NC,1),1) 1+zeros(size(NC,1),1)];
    ncY(:,1)=0; 
    ncY(:,2)=1;  % NC code in the first layer is [0 1]
    for i=1:clustNum
        exemp=unique(idx);
        if i==1
            ncY(find(idx==exemp(i,1)),5)=1;           
        else if i==2
                ncY(find(idx==exemp(i,1)),6)=1;
            else if i==3
                   ncY(find(idx==exemp(i,1)),7)=1;
                end
            end
        end       
    end       

    
    
    layer1=unique(idx);
    NC1=NC(find(idx==layer1(1,1)),:);
    NC2=NC(find(idx==layer1(2,1)),:);
    NC3=NC(find(idx==layer1(3,1)),:);
        
    [s,p]=computSimilarity(NC1);
%     [idx_1,netsim,dpsim,expref]=apcluster(s,p);  
    clustNum=2;
    [idx_1,netsim,dpsim,expref,pref]=apclusterK(s,clustNum) % clustering into k clusters
    fprintf('NC Layer 2:  sub-Class 1 has Number of clusters: %d\n',length(unique(idx_1)));
    
    [s,p]=computSimilarity(NC2);
%     [idx_2,netsim,dpsim,expref]=apcluster(s,p);  
    clustNum=2;
    [idx_2,netsim,dpsim,expref,pref]=apclusterK(s,clustNum) % clustering into k clusters
    fprintf('NC Layer 2:  sub-Class 2 has Number of clusters: %d\n',length(unique(idx_2)));

     [s,p]=computSimilarity(NC3);
%     [idx_2,netsim,dpsim,expref]=apcluster(s,p);  
    clustNum=2;
    [idx_3,netsim,dpsim,expref,pref]=apclusterK(s,clustNum) % clustering into k clusters
    fprintf('NC Layer 3:  sub-Class 3 has Number of clusters: %d\n',length(unique(idx_3)));

      
    
    sigma=mean(pdist(AD));
    j=1;
    for i=1:size(AD,1)
        for k=[1:i-1,i+1:size(AD,1)]
%           DisSimi_Matrix = 1 - MI_GG( double(AD(i,:)) , double(AD(j,:)) );  % Dis-similarity computation
%           DisSimi_Matrix = - sum( AD(i,:) , AD(j,:) );  % Dis-similarity computation
            s(j,1)=i; s(j,2)=k; s(j,3)=exp( -sum((AD(i,:)-AD(k,:)).^2)/ sigma);
            j=j+1;
        end
    end
 
    p=median(s(:,3));
%     [idx,netsim,dpsim,expref]=apcluster(s,p);    
    clustNum=5;
    [idx,netsim,dpsim,expref,pref]=apclusterK(s,clustNum) % clustering into k clusters

    fprintf('AD sigma Number of clusters: %d\n',length(unique(idx)));
    fprintf('AD sigma Fitness (net similarity): %g\n',netsim);
%     
    
    %% AD AP_clustering no pre-defined cluster number
    j=1;
    for i=1:size(AD,1)
        for k=[1:i-1,i+1:size(AD,1)]
%           DisSimi_Matrix = 1 - MI_GG( double(AD(i,:)) , double(AD(j,:)) );  % Dis-similarity computation
            s(j,1)=i; s(j,2)=k; s(j,3)=-sum((AD(i,:)-AD(k,:)).^2);
            j=j+1;
        end
    end
    
    p=median(s(:,3));
    [idx,netsim,dpsim,expref]=apcluster(s,p);  
%     clustNum=5;
%     [idx,netsim,dpsim,expref,pref]=apclusterK(s,clustNum) % clustering into k clusters

    fprintf('AD Number of clusters: %d\n',length(unique(idx)));
    fprintf('AD Fitness (net similarity): %g\n',netsim);
    
        sigma=mean(pdist(AD));
    for i=1:size(AD,1)
        for k=[1:i-1,i+1:size(AD,1)]
%           DisSimi_Matrix = 1 - MI_GG( double(AD(i,:)) , double(AD(j,:)) );  % Dis-similarity computation
%           DisSimi_Matrix = - sum( AD(i,:) , AD(j,:) );  % Dis-similarity computation
            s(j,1)=i; s(j,2)=k; s(j,3)=exp( -sum((AD(i,:)-AD(k,:)).^2)/ sigma);
            j=j+1;
        end
    end
 
    p=median(s(:,3));
%     [idx,netsim,dpsim,expref]=apcluster(s,p);    
    clustNum=5;
    [idx,netsim,dpsim,expref,pref]=apclusterK(s,clustNum) % clustering into k clusters

    fprintf('AD sigma Number of clusters: %d\n',length(unique(idx)));
    fprintf('AD sigma Fitness (net similarity): %g\n',netsim);
    
    %% NC AP_ clustering
    
        j=1;
    for i=1:size(NC,1)
        for k=[1:i-1,i+1:size(NC,1)]
%           DisSimi_Matrix = 1 - MI_GG( double(AD(i,:)) , double(AD(j,:)) );  % Dis-similarity computation
%           DisSimi_Matrix = - sum( AD(i,:) , AD(j,:) );  % Dis-similarity computation
            s(j,1)=i; s(j,2)=k; s(j,3)= (-sum((NC(i,:)-NC(k,:)).^2));
            j=j+1;
        end
    end
    
    p=median(s(:,3));
%     [idx,netsim,dpsim,expref]=apcluster(s,p);    
    clustNum=5;
    [idx,netsim,dpsim,expref,pref]=apclusterK(s,clustNum) % clustering into k clusters

    fprintf('NC Number of clusters: %d\n',length(unique(idx)));
    fprintf('NC Fitness (net similarity): %g\n',netsim);
    
    j=1;
    sigma=mean(pdist(NC));
    for i=1:size(NC,1)
        for k=[1:i-1,i+1:size(NC,1)]
%           DisSimi_Matrix = 1 - MI_GG( double(AD(i,:)) , double(AD(j,:)) );  % Dis-similarity computation
%           DisSimi_Matrix = - sum( AD(i,:) , AD(j,:) );  % Dis-similarity computation
            s(j,1)=i; s(j,2)=k; s(j,3)=exp( -sum((NC(i,:)-NC(k,:)).^2)/ sigma);
            j=j+1;
        end
    end
    
    p=median(s(:,3));
%     [idx,netsim,dpsim,expref]=apcluster(s,p);    
    clustNum=5;
    [idx,netsim,dpsim,expref,pref]=apclusterK(s,clustNum) % clustering into k clusters

    fprintf('NC sigma Number of clusters: %d\n',length(unique(idx)));
    fprintf('NC sigma Fitness (net similarity): %g\n',netsim);
    
    
    
    %%
    
    trData=[]; teData=[];trLab=[];teLab=[];
    trData=folds_data{1,fold_num}(:, (a_num-1)*1500+1:(a_num-1)*1500+1500 );
    trainLabel=folds_data{2,fold_num};
    teData=folds_data{3,fold_num}(:, (a_num-1)*1500+1:(a_num-1)*1500+1500 );
    testLabel=folds_data{4,fold_num};
 
    % select 10% of training data as validataion data
    bb=randperm(size(trData,1));
    validData=[]; validLabel=[];   
    validNum=bb( 1 : fix( 0.1*size(trData,1) ) );
    validData=trData(validNum,:);
    validLabel=trainLabel(validNum,:);

    trData(validNum,:)=[];
    trainLabel(validNum,:)=[];   
    newTrSize=size(trData,1);
  

 

  
end  % fold number
    
aa=1;
aa=1;
end 



end

