function [ output_args ] = singleAtlasAP(  )
%SINGLEATLASAP Summary of this function goes here
%   Detailed explanation goes here

clc
clear
load '../Rui_Data/ADNC_MA_10folds_NEW.mat'

fold=10;
model=[]; 
rep_num=1;

allTask_num=10;    
   
for fold_num=1:1:1%fold
    
  for a_num=1:10       
  %% Step 1: Prepare Data      
    fea_num=1500;  
    adTr_num=length( find(folds_data{2,fold_num}==1) );
    adTe_num=length( find(folds_data{4,fold_num}==1) );
    ncTr_num=length( find(folds_data{2,fold_num}==-1) );
    ncTe_num=length( find(folds_data{4,fold_num}==-1) );
    
    X=[folds_data{1,fold_num}(:, (a_num-1)*1500+1:(a_num-1)*1500+1500 );
       folds_data{3,fold_num}(:, (a_num-1)*1500+1:(a_num-1)*1500+1500 )];
    Y=[folds_data{2,fold_num};folds_data{4,fold_num}];
   
    AD=X(find(Y==1),:);
    adIndex=find(Y==1);
    NC=X(find(Y==-1),:);
    ncIndex=find(Y==-1);
    
    %% NC AP_clustering  cluster number is k.
    [s,p]=computSimilarity(NC);
    clustNum=3;
    [idx,netsim,dpsim,expref,pref]=apclusterK(s,clustNum) % clustering into k clusters
    
    ncY=zeros(size(NC,1),7 );%[];%[zeros(size(NC,1),1) 1+zeros(size(NC,1),1)];
    ncY(:,1)=0; 
    ncY(:,2)=1;  % NC code in the first layer is [0 1]
    for i=1:clustNum
        exemp=unique(idx);
        if i==1
            ncY(find(idx==exemp(i,1)),5)=1;           
        else if i==2
                ncY(find(idx==exemp(i,1)),6)=1;
            else if i==3
                   ncY(find(idx==exemp(i,1)),7)=1;
                end
            end
        end       
    end       

    %% AD AP_clustering  cluster number is k.
    [s,p]=computSimilarity(AD);
    clustNum=2;
    [idx,netsim,dpsim,expref,pref]=apclusterK(s,clustNum) % clustering into k clusters
    
    adY=zeros(size(AD,1),7 );%[];%[zeros(size(NC,1),1) 1+zeros(size(NC,1),1)];
    adY(:,1)=1; 
    adY(:,2)=0;  % NC code in the first layer is [0 1]
    for i=1:clustNum
        exemp=unique(idx);
        if i==1
            adY(find(idx==exemp(i,1)),3)=1;           
        else if i==2
                adY(find(idx==exemp(i,1)),4)=1;
            end
        end       
    end
    
    %% Prepare data and New Label
    
    trData=[]; teData=[];trLab=[];teLab=[];
    
    trData=[AD(1:adTr_num,:);NC(1:ncTr_num,:)];
    trLabel=[adY(1:adTr_num,:);ncY(1:ncTr_num,:)];  
    
    teData=[AD(1:adTe_num,:);NC(1:ncTe_num,:)];
    teLabel=[adY(1:adTe_num,:);ncY(1:ncTe_num,:)];
     
    % select 10% of training data as validataion data
    bb=randperm(size(trData,1));
    vaData=[]; vaLabel=[];   
    vaNum=bb( 1 : fix( 0.1*size(trData,1) ) );
    vaData=trData(vaNum,:);
    vaLabel=trLabel(vaNum,:);

    trData(vaNum,:)=[];
    trLabel(vaNum,:)=[];   
    newTrSize=size(trData,1);
    
    %% Using L2,1 regularized Multi-task Feature Selction

    A=[];
    for ii=1:size(trLabel,2)
        A=[A;trData];
    end
    
    ind=0:size(trData,1):size(trData,1)*size(trLabel,2);     % the 1000 samples are from 10 tasks
    q=2;                % the value of q in the L1/Lq regularization
    rho=0.05;            % the regularization parameter   
    
    addpath('../../Toolbox/SLEP-4.1')
    %----- Set optional items -
    opts=[];  % Starting point
    opts.init=2;        % starting from a zero point
    opts.tFlag=5;       % run .maxIter iterations
    opts.maxIter=100;   % maximum number of iterations
    opts.nFlag=0;       % without normalization
    % Regularization
    opts.rFlag=1;       % the input parameter 'rho' is a ratio in (0, 1)
    % Group Property
    opts.q=q;           % set the value for q
    opts.ind=ind;       % set the group indices

    %----------------------- Run the code mtLeastR -----------------------
    fprintf('\n mFlag=0, lFlag=0 \n');
    opts.mFlag=0;       % treating it as compositive function 
    opts.lFlag=0;       % Nemirovski's line search
    tic;
    [x1, funVal1, ValueL1]= mtLeastR(A, trLabel(:), rho, opts);
    toc;
aa=1;
 

  
end  % fold number
    
aa=1;
aa=1;
end 



end

