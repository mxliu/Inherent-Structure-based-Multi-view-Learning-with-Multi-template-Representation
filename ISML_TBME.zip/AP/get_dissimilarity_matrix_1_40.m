%% This is to get dissimilarity matrix of AD and NC brains
% AD = Alzheimer's Disease
% MCI = Mild Cognitive Impairment
% NC = Normal Control
clc;
clear all;
close all;

addpath /shenlab/lab_stor2/rmin/data/BrainDB/;
addpath utilities;
addpath data;

workspace='/shenlab/lab_stor2/rmin/';

fromMCI=strcat(workspace,'data/BrainDB/MCI/');
fromNC=strcat(workspace,'data/BrainDB/NC/');

load BDBoxMCINC;

MCINames=dir(strcat(fromMCI,'*.hdr'));
NCNames=dir(strcat(fromNC,'*.hdr'));

NoMCI=length(MCINames)/2;
NoNC=length(NCNames)/2;

ImageSize=[256 256 256];
BrainSize=[BD_x_max-BD_x_min+1 BD_y_max-BD_y_min+1 BD_z_max-BD_z_min+1];
Dissimilarity_Matrix_1_40=zeros(40,NoMCI+NoNC);

diary('1_40');
tic;
m=1;
for i=1:40
    name=strcat(fromMCI,'Image_',num2str(i),'.hdr');
    Image = analyze75read(name);
    Brain=Image(BD_x_min:BD_x_max,BD_y_min:BD_y_max,BD_z_min:BD_z_max);
    Representation_1=double(reshape(Brain,1,prod(BrainSize)));
    n=1;
    for j=1:NoMCI
        name=strcat(fromMCI,'Image_',num2str(j),'.hdr');
        Image = analyze75read(name);
        Brain=Image(BD_x_min:BD_x_max,BD_y_min:BD_y_max,BD_z_min:BD_z_max);
        Representation_2=double(reshape(Brain,1,prod(BrainSize)));
        Dissimilarity_Matrix_1_40(m,n) = 1-MI_GG(Representation_1,Representation_2);
        n=n+1;
    end
    for j=1:NoNC
        name=strcat(fromNC,'Image_',num2str(j),'.hdr');
        Image = analyze75read(name);
        Brain=Image(BD_x_min:BD_x_max,BD_y_min:BD_y_max,BD_z_min:BD_z_max);
        Representation_2=double(reshape(Brain,1,prod(BrainSize)));
        Dissimilarity_Matrix_1_40(m,n) = 1-MI_GG(Representation_1,Representation_2);
        n=n+1;
    end
    m=m+1;
end
elapsedTime = toc

save('Dissimilarity_Matrix_1_40','Dissimilarity_Matrix_1_40');