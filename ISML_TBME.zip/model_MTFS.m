function [model] = model_MTFS(X, Y,ind)


addpath( '../Toolbox/SLEP-4.1')
    
 % Regularization terms should be in range [0,1]
%   myRange=[0.001,  0.005,  0.01, 0.05, 0.1, 0.3, 0.5];
  myRange=[2^-10, 2^-9, 2^-8, 2^-7, 2^-6, 2^-4, 2^-3, 2^-2, 0.3, 0.4, 2^-1, 1];
  
%  myRange=[1e-10, 1e-9, 1e-8,1e-7, 1e-6,1e-5, 1e-4, 1e-3,1e-2, 1e-1, 1e0, 1e1, 1e2, 1e3, 1e4, 1e5];

%   myRange=[2^-10,0.01, 2^-1]%, 2^-1];%, 2^3, 2^4, 2^5, 2^6, 2^7, 2^8, 2^9, 2^10];

    %----- Set optional items -
    q=2;                % the value of q in the L1/Lq regularization
    opts.init=2;        % starting from a zero point
    opts.tFlag=5;       % run .maxIter iterations
    opts.maxIter=100;   % maximum number of iterations
    opts.nFlag=0;       % without normalization
    % Regularization
    opts.rFlag=1;       % the input parameter 'rho' is a ratio in (0, 1)
    % Group Property
    opts.q=q;           % set the value for q
    opts.ind=ind;       % set the group indices

    %----------------------- Run the code mtLeastR -----------------------
    opts.mFlag=0;       % treating it as compositive function 
    opts.lFlag=0;       % Nemirovski's line search
    
    num_iter=1; 
    model=[];
    for ii=1:size(myRange,2)
        rho=myRange(1,ii);
        [x1, funVal1, ~]= mtLeastR(X, Y, rho, opts);
        model.W{num_iter}=x1;
        model.fun_value{num_iter}=funVal1;          
        num_iter=num_iter+1;  
    end

end